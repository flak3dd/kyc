import json
import urllib.request
import urllib.parse
from typing import Dict, Any

class ComfyUIClient:
    def __init__(self, server_address="127.0.0.1:8188"):
        self.server_address = server_address

    def queue_prompt(self, prompt: Dict[str, Any]) -> dict:
        """
        Sends the workflow dictionary to the ComfyUI API queue.
        """
        p = {"prompt": prompt}
        data = json.dumps(p).encode('utf-8')
        req = urllib.request.Request(f"http://{self.server_address}/prompt", data=data)
        
        try:
            with urllib.request.urlopen(req) as response:
                return json.loads(response.read())
        except Exception as e:
            print(f"Failed to queue prompt: {e}")
            return {}

    def run_workflow(self, workflow_path: str):
        """
        Loads a JSON workflow and queues it.
        """
        try:
            with open(workflow_path, "r", encoding="utf-8") as f:
                workflow = json.load(f)
            
            print(f"Queueing workflow from {workflow_path}...")
            result = self.queue_prompt(workflow)
            print(f"Result: {result}")
        except FileNotFoundError:
            print(f"Error: Workflow {workflow_path} not found.")

if __name__ == "__main__":
    client = ComfyUIClient()
    
    print("Testing connection and queueing workflows...")
    # Example execution (will fail if ComfyUI is not running on localhost:8188)
    client.run_workflow("../comfyui_workflows/id_document_editor.json")
    client.run_workflow("../comfyui_workflows/face_swap_liveness.json")
    client.run_workflow("../comfyui_workflows/spoof_artifact_injector.json")
